from pybricks.hubs import PrimeHub
from pybricks.parameters import Port, Axis, Direction ,Color
from pybricks.pupdevices import Motor
from pybricks.robotics import DriveBase
from pybricks.tools import wait, multitask, run_task
from setup import initialize_robot

async def run1(hub ,robot, left_wheel, right_wheel,left_lift,right_lift):
 # 左アームを動かし始める（非同期）
    await left_lift.run_angle(200, 360,)
    wait(500)               # 少し遅れて...
    
    # 右アームも動かし始める（非同期）
    await right_lift.run_angle(300, -180,)
    await wait(200)
    
    # 両方のアームが動いている間にローバーも移動
    await robot.straight(300)
    
    # 左アームの動作が終わったら別の動作
    await wait(1000)              # 左アーム完了を待つ
    await left_lift.run_angle(400, -180)  # 左アームを逆方向に
    
    # 右アームはまだ動いている可能性があるので待つ
    await wait(800)               # 右アーム完了を待つ
    await right_lift.run_angle(400, 90)   # 右アームの追加動作
############################################################################
hub ,robot, left_wheel, right_wheel,left_lift,right_lift = initialize_robot()
async def main():
    await run1(hub ,robot, left_wheel, right_wheel,left_lift,right_lift)
run_task(main())